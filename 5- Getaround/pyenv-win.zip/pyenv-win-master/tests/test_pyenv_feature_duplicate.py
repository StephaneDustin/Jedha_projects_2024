

def test_check_pyenv_duplicate(pyenv):
    # TODO: assert the list of commands
    stdout, stderr = pyenv()
    pass


def test_check_pyenv_commands_help():
    # TODO: assert the help result
    pass
