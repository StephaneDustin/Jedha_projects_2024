

def test_check_pyenv_commands_list(pyenv):
    # TODO: assert the list of commands
    stdout, stderr = pyenv()
    pass


def test_check_pyenv_commands_help():
    # TODO: assert the help result
    pass
